package com.example.qian.test;

/**
 * Created by john on 2016/2/19.
 */
public class Information {
    int iconId;
    String title;
}
